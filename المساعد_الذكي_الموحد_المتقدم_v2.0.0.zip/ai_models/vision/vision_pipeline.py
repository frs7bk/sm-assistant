# Unified interface for vision models
