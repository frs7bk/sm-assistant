# GPT-4 for generating natural language responses
