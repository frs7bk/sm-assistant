
#!/usr/bin/env python3
"""
مثال على استخدام المساعد الذكي الموحد المتقدم
"""

import asyncio
from main_unified import AdvancedUnifiedAssistant

async def example_usage():
    """مثال على الاستخدام"""
    
    # إنشاء المساعد
    assistant = AdvancedUnifiedAssistant()
    
    try:
        # تهيئة المحركات
        await assistant.initialize_engines()
        
        # مثال على التفاعل
        test_queries = [
            "مرحباً، كيف حالك؟",
            "ما هو الطقس اليوم؟",
            "ساعدني في تحليل البيانات",
            "ما هي توصياتك لي؟"
        ]
        
        print("🤖 اختبار المساعد الذكي")
        print("=" * 40)
        
        for query in test_queries:
            print(f"\n👤 المستخدم: {query}")
            response = await assistant.process_user_input(query)
            print(f"🤖 المساعد: {response}")
        
        # عرض الإحصائيات
        print("\n" + "=" * 40)
        stats = assistant.get_session_stats()
        print(stats)
        
    finally:
        # تنظيف الموارد
        await assistant.cleanup()

if __name__ == "__main__":
    asyncio.run(example_usage())
