
#!/usr/bin/env python3
"""
💡 أمثلة شاملة لاستخدام المساعد الذكي الموحد المتقدم
"""

import asyncio
import sys
from pathlib import Path

# إضافة مسار المشروع
sys.path.append(str(Path(__file__).parent))

from main_unified import AdvancedUnifiedAssistant

async def example_basic_interaction():
    """مثال على التفاعل الأساسي"""
    print("🤖 مثال: التفاعل الأساسي")
    print("=" * 40)
    
    assistant = AdvancedUnifiedAssistant()
    await assistant.initialize_engines()
    
    # أمثلة على الاستعلامات
    queries = [
        "مرحباً، كيف حالك؟",
        "ما هو الطقس اليوم؟", 
        "ساعدني في تنظيم مهامي",
        "احسب لي 15 × 24 + 100",
        "اشرح لي الذكاء الاصطناعي"
    ]
    
    for query in queries:
        print(f"\n👤 المستخدم: {query}")
        response = await assistant.process_user_input(query)
        print(f"🤖 المساعد: {response}")
    
    await assistant.cleanup()

async def example_advanced_features():
    """مثال على الميزات المتقدمة"""
    print("\n🚀 مثال: الميزات المتقدمة")
    print("=" * 40)
    
    assistant = AdvancedUnifiedAssistant()
    await assistant.initialize_engines()
    
    # تحليل البيانات الضخمة
    print("\n📊 تحليل البيانات الضخمة:")
    data_analysis = await assistant.analyze_big_data()
    print(data_analysis)
    
    # التوقعات الذكية
    print("\n🔮 التوقعات الذكية:")
    predictions = await assistant.make_predictions()
    print(predictions)
    
    # الإحصائيات
    print("\n📈 إحصائيات الجلسة:")
    stats = assistant.get_session_stats()
    print(stats)
    
    await assistant.cleanup()

async def example_learning_adaptation():
    """مثال على التعلم والتكيف"""
    print("\n🧠 مثال: التعلم والتكيف")
    print("=" * 40)
    
    assistant = AdvancedUnifiedAssistant()
    await assistant.initialize_engines()
    
    # تسلسل من التفاعلات لإظهار التعلم
    learning_sequence = [
        "أحب القهوة في الصباح",
        "أفضل العمل في المساء", 
        "أحتاج تذكيرات للاجتماعات",
        "ما هي توصياتك بناءً على تفضيلاتي؟"
    ]
    
    print("تسلسل التعلم:")
    for i, query in enumerate(learning_sequence, 1):
        print(f"\n{i}. 👤 المستخدم: {query}")
        response = await assistant.process_user_input(query)
        print(f"   🤖 المساعد: {response}")
        
        # محاكاة التعلم من التفاعل
        if assistant.active_learning:
            assistant.active_learning.log_interaction(query, response)
    
    await assistant.cleanup()

async def example_specialized_modules():
    """مثال على الوحدات المتخصصة"""
    print("\n🎯 مثال: الوحدات المتخصصة")
    print("=" * 40)
    
    assistant = AdvancedUnifiedAssistant()
    await assistant.initialize_engines()
    
    # اختبار وحدات مختلفة
    specialized_queries = [
        "حلل هذه الصورة",  # الرؤية الحاسوبية
        "اقترح استثمارات ذكية",  # المستشار المالي
        "راقب صحتي اليوم",  # مراقب الصحة
        "ساعدني في إدارة المشروع",  # إدارة المشاريع
        "حلل مشاعري من النص",  # تحليل المشاعر
    ]
    
    for query in specialized_queries:
        print(f"\n🎯 اختبار: {query}")
        response = await assistant.process_user_input(query)
        print(f"📋 النتيجة: {response}")
    
    await assistant.cleanup()

async def demo_full_capabilities():
    """عرض توضيحي كامل للقدرات"""
    print("\n" + "🌟" * 20)
    print("🎭 عرض توضيحي كامل لقدرات المساعد")
    print("🌟" * 20)
    
    try:
        # التفاعل الأساسي
        await example_basic_interaction()
        
        # الميزات المتقدمة
        await example_advanced_features()
        
        # التعلم والتكيف
        await example_learning_adaptation()
        
        # الوحدات المتخصصة
        await example_specialized_modules()
        
        print("\n" + "✨" * 20)
        print("🎉 انتهى العرض التوضيحي بنجاح!")
        print("💡 يمكنك الآن استخدام المساعد بكامل قدراته")
        print("✨" * 20)
        
    except Exception as e:
        print(f"\n❌ خطأ في العرض التوضيحي: {e}")

if __name__ == "__main__":
    print("🤖 أمثلة استخدام المساعد الذكي الموحد المتقدم")
    print("=" * 60)
    print("اختر ما تريد تجربته:")
    print("1. التفاعل الأساسي")
    print("2. الميزات المتقدمة") 
    print("3. التعلم والتكيف")
    print("4. الوحدات المتخصصة")
    print("5. عرض كامل لجميع القدرات")
    print("=" * 60)
    
    try:
        choice = input("اختر رقم (1-5): ").strip()
        
        if choice == "1":
            asyncio.run(example_basic_interaction())
        elif choice == "2":
            asyncio.run(example_advanced_features())
        elif choice == "3":
            asyncio.run(example_learning_adaptation())
        elif choice == "4":
            asyncio.run(example_specialized_modules())
        elif choice == "5":
            asyncio.run(demo_full_capabilities())
        else:
            print("❌ اختيار غير صحيح")
            
    except KeyboardInterrupt:
        print("\n👋 تم إيقاف الأمثلة")
    except Exception as e:
        print(f"\n❌ خطأ: {e}")
