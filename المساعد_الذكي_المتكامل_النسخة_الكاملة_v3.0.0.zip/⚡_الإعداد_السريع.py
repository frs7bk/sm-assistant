
#!/usr/bin/env python3
"""
⚡ سكريبت الإعداد السريع للمساعد الذكي
"""

import os
import sys
import subprocess
import platform
from pathlib import Path

def print_colored(message, color="white"):
    """طباعة ملونة"""
    colors = {
        "red": "\033[91m",
        "green": "\033[92m", 
        "yellow": "\033[93m",
        "blue": "\033[94m",
        "purple": "\033[95m",
        "cyan": "\033[96m",
        "white": "\033[97m",
        "reset": "\033[0m"
    }
    
    print(f"{colors.get(color, colors['white'])}{message}{colors['reset']}")

def check_python_version():
    """فحص إصدار Python"""
    print_colored("🔍 فحص إصدار Python...", "blue")
    
    if sys.version_info < (3, 8):
        print_colored("❌ يتطلب Python 3.8 أو أحدث", "red")
        return False
    
    print_colored(f"✅ Python {sys.version.split()[0]} - متوافق", "green")
    return True

def install_requirements():
    """تثبيت المتطلبات"""
    print_colored("📦 تثبيت المتطلبات...", "blue")
    
    requirements_file = Path("requirements.txt")
    
    if not requirements_file.exists():
        print_colored("⚠️ ملف requirements.txt غير موجود، إنشاء ملف أساسي...", "yellow")
        create_basic_requirements()
    
    try:
        subprocess.run([
            sys.executable, "-m", "pip", "install", "-r", "requirements.txt"
        ], check=True, capture_output=True)
        
        print_colored("✅ تم تثبيت جميع المتطلبات", "green")
        return True
        
    except subprocess.CalledProcessError as e:
        print_colored(f"❌ خطأ في التثبيت: {e}", "red")
        return False

def create_basic_requirements():
    """إنشاء ملف متطلبات أساسي"""
    basic_requirements = """
# المتطلبات الأساسية
colorama>=0.4.4
python-dotenv>=0.19.0
requests>=2.25.1
numpy>=1.21.0
pandas>=1.3.0

# معالجة النصوص والذكاء الاصطناعي
openai>=0.27.0
transformers>=4.15.0
torch>=1.9.0
sentence-transformers>=2.1.0

# معالجة الصوت والصورة
pillow>=8.3.0
opencv-python>=4.5.0
librosa>=0.8.1
soundfile>=0.10.3

# واجهات الويب والتصور
flask>=2.0.0
dash>=2.0.0
plotly>=5.0.0
streamlit>=1.0.0

# قواعد البيانات والتخزين
sqlalchemy>=1.4.0
redis>=3.5.0
pymongo>=3.12.0

# أدوات التطوير
pytest>=6.2.0
black>=21.0.0
flake8>=3.9.0
""".strip()
    
    with open("requirements.txt", "w", encoding="utf-8") as f:
        f.write(basic_requirements)

def setup_environment():
    """إعداد البيئة"""
    print_colored("🔧 إعداد البيئة...", "blue")
    
    # إنشاء ملف .env إذا لم يكن موجوداً
    env_file = Path(".env")
    if not env_file.exists():
        env_example = Path(".env.example")
        if env_example.exists():
            import shutil
            shutil.copy(env_example, env_file)
            print_colored("✅ تم إنشاء ملف .env", "green")
        else:
            create_basic_env_file()
    
    # إنشاء المجلدات الأساسية
    essential_dirs = [
        "data/logs",
        "data/cache", 
        "data/models",
        "data/user_data",
        "temp"
    ]
    
    for dir_path in essential_dirs:
        Path(dir_path).mkdir(parents=True, exist_ok=True)
    
    print_colored("✅ تم إعداد البيئة", "green")

def create_basic_env_file():
    """إنشاء ملف .env أساسي"""
    env_content = """
# مفاتيح API الأساسية
OPENAI_API_KEY=your_openai_key_here
HUGGINGFACE_API_KEY=your_hf_key_here

# إعدادات المساعد
ASSISTANT_NAME=المساعد الذكي
ASSISTANT_LANGUAGE=ar
DEBUG_MODE=False

# إعدادات الأداء
MAX_MEMORY_USAGE=4GB
ENABLE_GPU=True
PARALLEL_PROCESSING=True
""".strip()
    
    with open(".env", "w", encoding="utf-8") as f:
        f.write(env_content)
    
    print_colored("ℹ️ تم إنشاء ملف .env أساسي - لا تنس إضافة مفاتيح API", "yellow")

def run_initial_test():
    """تشغيل اختبار أولي"""
    print_colored("🧪 تشغيل اختبار أولي...", "blue")
    
    try:
        # اختبار استيراد المكتبات الأساسية
        import colorama
        import numpy
        import pandas
        
        print_colored("✅ جميع المكتبات الأساسية تعمل", "green")
        
        # اختبار تشغيل المساعد
        if Path("main_unified.py").exists():
            print_colored("✅ ملف المساعد الرئيسي موجود", "green")
            return True
        else:
            print_colored("⚠️ ملف المساعد الرئيسي غير موجود", "yellow")
            return False
            
    except ImportError as e:
        print_colored(f"❌ خطأ في الاستيراد: {e}", "red")
        return False

def main():
    """الدالة الرئيسية للإعداد"""
    print_colored("=" * 60, "cyan")
    print_colored("⚡ معالج الإعداد السريع للمساعد الذكي", "cyan")
    print_colored("=" * 60, "cyan")
    
    steps = [
        ("فحص إصدار Python", check_python_version),
        ("تثبيت المتطلبات", install_requirements), 
        ("إعداد البيئة", setup_environment),
        ("تشغيل اختبار أولي", run_initial_test)
    ]
    
    success_count = 0
    
    for step_name, step_func in steps:
        print_colored(f"\n📋 {step_name}...", "purple")
        if step_func():
            success_count += 1
        else:
            print_colored(f"⚠️ فشل في: {step_name}", "yellow")
    
    print_colored("\n" + "=" * 60, "cyan")
    
    if success_count == len(steps):
        print_colored("🎉 تم الإعداد بنجاح!", "green")
        print_colored("🚀 يمكنك الآن تشغيل المساعد:", "green")
        print_colored("   python main_unified.py", "white")
    else:
        print_colored(f"⚠️ نجح {success_count}/{len(steps)} خطوات", "yellow")
        print_colored("💡 تحقق من السجلات وأعد المحاولة", "yellow")
    
    print_colored("=" * 60, "cyan")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print_colored("\n⚠️ تم إيقاف الإعداد", "yellow")
    except Exception as e:
        print_colored(f"\n❌ خطأ في الإعداد: {e}", "red")
