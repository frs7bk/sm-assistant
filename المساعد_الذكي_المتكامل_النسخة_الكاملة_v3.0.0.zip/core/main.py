
import pyautogui
import pyttsx3
import openai

def run():
    assistant = AdvancedPersonalAssistant()
    assistant.assist_with_tasks()

if __name__ == '__main__':
    run()
